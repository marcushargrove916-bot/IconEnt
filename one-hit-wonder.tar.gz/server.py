#!/usr/bin/env python3
"""One Hit Wonder — tiny self-hosted AI text-to-video web app.

This server uses fal.ai's Gemini Omni Flash 1.1 queue API.  API credentials
stay on the server; they are never returned to the browser.
"""
from __future__ import annotations

import base64
import json
import logging
import mimetypes
import os
from pathlib import Path
import re
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from uuid import uuid4

ROOT = Path(__file__).resolve().parent
PUBLIC = ROOT / "public"
STORAGE_ROOT = Path(os.getenv("STORAGE_ROOT", str(ROOT))).expanduser()
DATA = STORAGE_ROOT / "data"
VIDEOS = STORAGE_ROOT / "videos"
for folder in (DATA, VIDEOS):
    folder.mkdir(exist_ok=True)
JOBS_FILE = DATA / "jobs.json"
MODEL = "google/gemini-omni-flash/v1.1/text-to-video"
FAL_QUEUE = f"https://queue.fal.run/{MODEL}"
HOST = os.getenv("HOST", "127.0.0.1")
PORT = int(os.getenv("PORT", "8080"))
FAL_KEY = os.getenv("FAL_KEY", "").strip()
APP_PASSWORD = os.getenv("APP_PASSWORD", "")
MAX_RUNNING = 2
MAX_HISTORY = 70
MAX_BYTES = 150 * 1024 * 1024
RATES = {"360p": 0.03, "720p": 0.10, "1080p": 0.15, "4k": 0.30}
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
LOCK = threading.RLock()


def timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_jobs():
    if not JOBS_FILE.is_file():
        return {}
    try:
        loaded = json.loads(JOBS_FILE.read_text(encoding="utf-8"))
        if not isinstance(loaded, dict):
            return {}
        for job in loaded.values():
            if job.get("status") in ("queued", "working", "saving"):
                job["status"] = "failed"
                job["error"] = "The server restarted during generation. Try again."
        return loaded
    except Exception:
        logging.exception("Unable to load jobs")
        return {}


JOBS = load_jobs()


def save_jobs():
    """Caller must hold LOCK."""
    to_keep = list(JOBS.values())
    to_keep.sort(key=lambda j: j["created_at"], reverse=True)
    for obsolete in to_keep[MAX_HISTORY:]:
        JOBS.pop(obsolete["id"], None)
    tmp = DATA / f"jobs.{secrets.token_hex(4)}.tmp"
    tmp.write_text(json.dumps(JOBS, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(JOBS_FILE)


def fal_request(url: str, *, payload: dict | None = None) -> dict:
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "https" or parsed.hostname != "queue.fal.run":
        raise ValueError("Unrecognized video generation queue URL")
    headers = {"Authorization": f"Key {FAL_KEY}", "Accept": "application/json"}
    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method="POST" if data else "GET")
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            obj = json.load(resp)
            if not isinstance(obj, dict):
                raise RuntimeError("Unexpected response from the generation provider")
            return obj
    except urllib.error.HTTPError as exc:
        err = exc.read(4000).decode("utf-8", errors="replace")
        try:
            detail = json.loads(err)
            msg = detail.get("detail") or detail.get("message") or detail.get("error") or err
            if not isinstance(msg, str):
                msg = json.dumps(msg)
        except Exception:
            msg = err
        raise RuntimeError(f"Video service returned {exc.code}: {msg[:400]}") from exc


def update_job(jid: str, **updates):
    with LOCK:
        if jid not in JOBS:
            return
        JOBS[jid].update(updates)
        JOBS[jid]["updated_at"] = timestamp()
        save_jobs()


def download_generated_video(url: str, jid: str):
    parsed = urllib.parse.urlsplit(url)
    host = (parsed.hostname or "").lower()
    if parsed.scheme != "https" or not (host == "fal.media" or host.endswith(".fal.media")):
        raise RuntimeError("The video provider returned an unsupported media URL")
    request = urllib.request.Request(url, headers={"User-Agent": "OneHitWonder/1.0"})
    destination = VIDEOS / f"{jid}.mp4"
    staging = VIDEOS / f"{jid}.part"
    downloaded = 0
    try:
        with urllib.request.urlopen(request, timeout=120) as upstream, staging.open("wb") as out:
            final_host = (urllib.parse.urlsplit(upstream.url).hostname or "").lower()
            if not (final_host == "fal.media" or final_host.endswith(".fal.media")):
                raise RuntimeError("Unsafe media redirect")
            while True:
                chunk = upstream.read(1024 * 1024)
                if not chunk:
                    break
                downloaded += len(chunk)
                if downloaded > MAX_BYTES:
                    raise RuntimeError("Generated video exceeded the 150 MB storage limit")
                out.write(chunk)
        if downloaded < 100:
            raise RuntimeError("Generated video was unexpectedly empty")
        staging.replace(destination)
    finally:
        staging.unlink(missing_ok=True)


def generate_video(jid: str):
    with LOCK:
        job = JOBS.get(jid)
        if job is None:
            return
        input_data = {key: job[key] for key in ("prompt", "aspect_ratio", "resolution", "duration")}
    try:
        update_job(jid, status="working", progress="Sending your idea to the AI studio…")
        submitted = fal_request(FAL_QUEUE, payload=input_data)
        request_id = submitted.get("request_id")
        status_url = submitted.get("status_url")
        response_url = submitted.get("response_url")
        if not request_id or not status_url or not response_url:
            raise RuntimeError("The video service did not return a valid job ID")
        update_job(jid, provider_request_id=request_id, progress="Your clip is in the render queue…")
        for attempt in range(180):  # up to about 15 minutes of waiting
            time.sleep(5)
            status_info = fal_request(status_url)
            state = status_info.get("status")
            if status_info.get("error"):
                raise RuntimeError(str(status_info["error"])[:400])
            if state == "COMPLETED":
                break
            if attempt % 3 == 0:
                message = ("Waiting for a render slot…" if state == "IN_QUEUE" else "AI is creating your scene and sound…")
                update_job(jid, progress=message)
        else:
            raise RuntimeError("The render took too long. Please try again or check your provider dashboard.")
        result = fal_request(response_url)
        if result.get("error"):
            raise RuntimeError(str(result["error"])[:400])
        media = result.get("video") or result.get("output", {}).get("video")
        video_url = media.get("url") if isinstance(media, dict) else None
        if not video_url:
            raise RuntimeError("The AI service completed without a downloadable video")
        update_job(jid, status="saving", progress="Finishing your MP4 download…")
        download_generated_video(video_url, jid)
        update_job(jid, status="completed", progress="Your video is ready!", video_url=f"/api/video/{jid}")
    except Exception as exc:
        logging.exception("Video job failed: %s", jid)
        update_job(jid, status="failed", progress="Unable to generate", error=str(exc)[:450])


class Handler(BaseHTTPRequestHandler):
    server_version = "OneHitWonder/1.0"

    def respond(self, status: int, payload: dict | list):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def authed(self) -> bool:
        if not APP_PASSWORD:
            return True
        auth = self.headers.get("Authorization", "")
        if not auth.startswith("Basic "):
            self._auth_required()
            return False
        try:
            val = base64.b64decode(auth.split(" ", 1)[1], validate=True).decode("utf-8")
            password = val.split(":", 1)[1]
        except Exception:
            self._auth_required()
            return False
        if not secrets.compare_digest(password, APP_PASSWORD):
            self._auth_required()
            return False
        return True

    def _auth_required(self):
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="One Hit Wonder Studio"')
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        path = urllib.parse.urlsplit(self.path).path
        # Health checks must be reachable by Render without owner credentials.
        if path == "/healthz":
            return self.respond(200, {"ok": True})
        if not self.authed():
            return
        if path == "/api/config":
            return self.respond(200, {
                "ready": bool(FAL_KEY), "engine": "Gemini Omni Flash 1.1",
                "rates": RATES, "max_running": MAX_RUNNING,
            })
        if path == "/api/jobs":
            with LOCK:
                jobs = sorted(JOBS.values(), key=lambda j: j["created_at"], reverse=True)[:24]
                return self.respond(200, {"jobs": jobs})
        matched = re.fullmatch(r"/api/jobs/([0-9a-f-]{36})", path)
        if matched:
            with LOCK:
                job = JOBS.get(matched.group(1))
                return self.respond(200, {"job": job}) if job else self.respond(404, {"error": "Video not found"})
        matched = re.fullmatch(r"/api/video/([0-9a-f-]{36})", path)
        if matched:
            jid = matched.group(1)
            with LOCK:
                job = JOBS.get(jid)
            file = VIDEOS / f"{jid}.mp4"
            if not job or job.get("status") != "completed" or not file.is_file():
                return self.respond(404, {"error": "Video not ready"})
            size = file.stat().st_size
            download = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query).get("download") == ["1"]
            # Safari and iOS video players use HTTP Range requests for MP4 seek/playback.
            range_header = self.headers.get("Range", "")
            start, end = 0, size - 1
            status = 200
            if range_header:
                match = re.fullmatch(r"bytes=(\d*)-(\d*)", range_header.strip())
                if not match:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{size}")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                a, b = match.groups()
                if a:
                    start = int(a)
                    end = int(b) if b else size - 1
                elif b:
                    start = max(0, size - int(b))
                    end = size - 1
                if start >= size or start > end:
                    self.send_response(416)
                    self.send_header("Content-Range", f"bytes */{size}")
                    self.send_header("Content-Length", "0")
                    self.end_headers()
                    return
                end = min(end, size - 1)
                status = 206
            self.send_response(status)
            self.send_header("Content-Type", "video/mp4")
            self.send_header("Content-Length", str(end - start + 1))
            self.send_header("Cache-Control", "private, max-age=3600")
            self.send_header("Accept-Ranges", "bytes")
            if status == 206:
                self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            if download:
                self.send_header("Content-Disposition", f'attachment; filename="one-hit-wonder-{jid[:8]}.mp4"')
            self.end_headers()
            try:
                remaining = end - start + 1
                with file.open("rb") as inp:
                    inp.seek(start)
                    while remaining > 0:
                        chunk = inp.read(min(1024 * 1024, remaining))
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                        remaining -= len(chunk)
            except (BrokenPipeError, ConnectionResetError):
                pass
            return
        if path == "/":
            path = "/index.html"
        pathname = (PUBLIC / path.lstrip("/")).resolve()
        if PUBLIC.resolve() not in pathname.parents or not pathname.is_file():
            return self.respond(404, {"error": "Not found"})
        ctype = mimetypes.guess_type(pathname.name)[0] or "application/octet-stream"
        if pathname.suffix == ".js":
            ctype = "text/javascript"
        content = pathname.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "public, max-age=3600")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(content)

    def do_POST(self):
        if not self.authed():
            return
        path = urllib.parse.urlsplit(self.path).path
        if path != "/api/jobs":
            return self.respond(404, {"error": "Not found"})
        if not FAL_KEY:
            return self.respond(503, {"error": "Connect your fal.ai API key to activate real AI video generation.", "code": "SETUP_REQUIRED"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 2 or length > 16384:
                return self.respond(413, {"error": "Video description is too long"})
            body = json.loads(self.rfile.read(length))
            if not isinstance(body, dict):
                raise ValueError("Invalid request")
            prompt = body.get("prompt", "")
            if not isinstance(prompt, str) or not 6 <= len(prompt.strip()) <= 2500:
                return self.respond(400, {"error": "Enter a video description between 6 and 2,500 characters"})
            ratio = body.get("aspect_ratio", "9:16")
            resolution = body.get("resolution", "720p")
            duration = body.get("duration", 8)
            if ratio not in ("9:16", "16:9") or resolution not in RATES or type(duration) is not int or not 3 <= duration <= 10:
                return self.respond(400, {"error": "Invalid video settings"})
            with LOCK:
                active = sum(x.get("status") in ("queued", "working", "saving") for x in JOBS.values())
                if active >= MAX_RUNNING:
                    return self.respond(429, {"error": "Two clips are already rendering. Wait for a clip to finish."})
                jid = str(uuid4())
                job = {
                    "id": jid, "status": "queued", "created_at": timestamp(),
                    "updated_at": timestamp(), "prompt": prompt.strip(),
                    "aspect_ratio": ratio, "resolution": resolution,
                    "duration": duration, "cost_estimate": round(RATES[resolution] * duration, 2),
                    "progress": "Preparing your video…", "video_url": None, "error": None,
                }
                JOBS[jid] = job
                save_jobs()
            threading.Thread(target=generate_video, args=(jid,), daemon=True, name=f"render-{jid[:8]}").start()
            return self.respond(202, {"job": job})
        except (ValueError, TypeError, json.JSONDecodeError):
            return self.respond(400, {"error": "Please check your input and try again"})


if __name__ == "__main__":
    if not FAL_KEY:
        logging.warning("FAL_KEY is missing. The UI works, but real video rendering is disabled.")
    if HOST == "0.0.0.0" and not APP_PASSWORD:
        logging.warning("Public access without APP_PASSWORD is not recommended; add authentication before exposing this app.")
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    logging.info("One Hit Wonder running at http://%s:%s", HOST, PORT)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        httpd.server_close()
