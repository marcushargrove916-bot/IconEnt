'use strict';
const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const state = {config: null, ratio: '9:16', currentJob: null, polling: null, view: 'studio', toastTimer: null};
const API = '/api';
const fmtMoney = (n) => new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(message) {
  const el = $('#toast'); el.textContent = message; el.hidden = false;
  clearTimeout(state.toastTimer); state.toastTimer = setTimeout(()=>el.hidden=true,4000);
}
async function api(url, options={}) {
  const resp = await fetch(`${API}${url}`, {headers:{'Content-Type':'application/json'}, cache:'no-store', ...options});
  let data;
  try {data = await resp.json()} catch {throw new Error('The studio could not read the server response.')}
  if (!resp.ok) throw new Error(data.error || `Server error (${resp.status})`);
  return data;
}
function estimate() {
  const duration = Number($('#duration').value), quality = $('#quality').value;
  const rates = state.config?.rates || {'360p':0.03,'720p':0.10,'1080p':0.15,'4k':0.30};
  $('#costEstimate').textContent = fmtMoney(duration * rates[quality]);
}
function updatePromptCounter() {
  $('#charCounter').textContent = `${$('#prompt').value.length.toLocaleString()} / 2,500`;
}
function switchView(name) {
  state.view = name;
  $('#studioView').hidden = name !== 'studio'; $('#libraryView').hidden = name !== 'library';
  $('#pageLabel').textContent = name === 'studio' ? 'Create' : 'My creations';
  $$('.nav-link').forEach(n=>n.classList.toggle('active', n.dataset.view===name));
  if (name === 'library') loadLibrary();
  window.scrollTo({top:0, behavior:'smooth'});
}
function setBadge(label, stateName='') {
  const b = $('#previewBadge'); b.innerHTML = `<span></span>${esc(label)}`;
  b.className = 'preview-status' + (stateName?` ${stateName}`:'');
}
function preview(which) {
  $('#emptyPreview').hidden = which !== 'empty';
  $('#renderingPreview').hidden = which !== 'rendering';
  $('#readyPreview').hidden = which !== 'ready';
}
function setBusy(busy) {
  $('#generateBtn').disabled = busy;
  $('#generateBtnText').textContent = busy ? 'Generating your video…' : 'Generate my video';
}
function showJob(job) {
  state.currentJob = job;
  $('#errorMessage').hidden = true;
  $('#downloadBtn').hidden = true;
  if (job.status === 'completed') {
    setBusy(false); setBadge('VIDEO READY', 'done'); preview('ready');
    const video = $('#resultVideo');
    const expected = job.video_url;
    if (video.getAttribute('src') !== expected) {video.src = expected;video.load();}
    $('#resultTitle').textContent = 'Your masterpiece is ready';
    $('#resultSub').textContent = `${job.duration}s · ${job.resolution} · ${job.aspect_ratio}`;
    $('#downloadBtn').href = `${job.video_url}?download=1`;
    $('#downloadBtn').hidden = false;
    $('#renderStatus').textContent = 'Complete';
    endPolling();
  } else if (job.status === 'failed') {
    setBusy(false); setBadge('RENDER FAILED'); preview('empty');
    $('#resultTitle').textContent = 'Let’s try another take';
    $('#resultSub').textContent = 'Check the message below';
    $('#errorMessage').textContent = job.error || 'The service could not complete the video.';
    $('#errorMessage').hidden = false;
    endPolling();
  } else {
    setBusy(true); preview('rendering'); setBadge('CREATING', 'busy');
    $('#renderStatus').textContent = job.progress || 'AI is generating your video…';
    $('#resultTitle').textContent = 'Your vision is taking shape';
    $('#resultSub').textContent = `${job.duration}s · ${job.resolution} · ${job.aspect_ratio}`;
  }
}
function endPolling(){if(state.polling){clearInterval(state.polling);state.polling=null}}
function startPolling(id) {
  endPolling();
  let fetching = false;
  state.polling = setInterval(async()=>{
    if(fetching) return;
    fetching = true;
    try {
      const {job} = await api(`/jobs/${id}`);
      if(job && state.currentJob?.id === id){
        const prior = state.currentJob.status;
        showJob(job);
        if(prior !== 'completed' && job.status === 'completed') {toast('✨ Your AI video is ready!'); loadLibrary();}
      }
    } catch(err){console.warn('Retrying status',err)}
    finally {fetching=false}
  },5000);
}
async function generate(){
  const prompt = $('#prompt').value.trim();
  if(prompt.length < 6) {toast('Describe your scene first — give the AI at least a few words.'); $('#prompt').focus(); return;}
  if(!state.config?.ready) {toast('Real video generation needs a fal.ai API key. See the setup notice.'); $('#setupBanner').hidden=false; $('#setupBanner').scrollIntoView({behavior:'smooth',block:'center'}); return;}
  if(state.currentJob && ['queued','working','saving'].includes(state.currentJob.status)) {toast('Your current video is still rendering.'); return;}
  $('#errorMessage').hidden = true;
  setBusy(true); preview('rendering'); setBadge('STARTING', 'busy');
  $('#renderStatus').textContent = 'Creating your render request…';
  try {
    const response = await api('/jobs', {method:'POST',body:JSON.stringify({prompt, aspect_ratio:state.ratio, duration:Number($('#duration').value),resolution:$('#quality').value})});
    showJob(response.job);
    startPolling(response.job.id);
    toast('Your video is rendering!');
  } catch(err) {
    setBusy(false); preview('empty'); setBadge('READY FOR IDEAS');
    $('#errorMessage').textContent = err.message; $('#errorMessage').hidden=false;
    toast(err.message);
  }
}
function formatDate(date){try{return new Date(date).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}catch{return ''}}
async function loadLibrary(){
  try {
    const {jobs} = await api('/jobs');
    $('#libraryCount').textContent = jobs.filter(j=>j.status==='completed').length;
    const grid = $('#libraryGrid'); grid.textContent = '';
    $('#libraryEmpty').hidden = jobs.length!==0;
    jobs.forEach(job=>{
      const card = document.createElement('article');card.className='library-card';
      const done = job.status==='completed';
      const label = done?'READY':job.status==='failed'?'FAILED':'RENDERING';
      const thumb = done?`<video src="${esc(job.video_url)}" playsinline preload="metadata" controls></video>`:`<span class="placeholder-symbol">✦</span>`;
      card.innerHTML=`<div class="library-thumb">${thumb}<span class="thumb-state">${label}</span></div><div class="library-card-body"><p title="${esc(job.prompt)}">${esc(job.prompt)}</p><div class="library-meta"><span>${esc(formatDate(job.created_at))} · ${esc(job.duration)}s</span>${done?`<a href="${esc(job.video_url)}?download=1" download>↓ Save MP4</a>`:`<span>${esc(job.resolution)}</span>`}</div></div>`;
      grid.appendChild(card);
    });
  } catch(err){toast(err.message)}
}
async function init(){
  $$('.nav-link').forEach(b=>b.addEventListener('click',()=>switchView(b.dataset.view)));
  $('#emptyCreate').addEventListener('click',()=>switchView('studio'));
  $('#libraryRefresh').addEventListener('click',loadLibrary);
  $$('.ratio-choice').forEach(b=>b.addEventListener('click',()=>{
    state.ratio = b.dataset.ratio;
    $$('.ratio-choice').forEach(el=>{el.classList.toggle('selected',el===b);el.setAttribute('aria-pressed',el===b?'true':'false')});
  }));
  $$('#promptChips .chip').forEach(chip=>chip.addEventListener('click',()=>{
    $('#prompt').value=chip.dataset.prompt;updatePromptCounter();toast('Prompt loaded. Make it your own!');
  }));
  $('#prompt').addEventListener('input',updatePromptCounter);
  $('#duration').addEventListener('change',estimate);$('#quality').addEventListener('change',estimate);
  $('#generateBtn').addEventListener('click',generate);
  updatePromptCounter(); estimate();
  try {
    const config = await api('/config'); state.config = config; estimate();
    $('#connectionDot').classList.add(config.ready?'online':'offline');
    $('#connectionText').textContent=config.ready?'AI engine connected':'Setup needed';
    $('#setupBanner').hidden=!!config.ready;
  } catch(err){$('#connectionText').textContent='Server unavailable';toast(err.message)}
  try {
    const {jobs}=await api('/jobs');
    $('#libraryCount').textContent=jobs.filter(j=>j.status==='completed').length;
    const job=jobs.find(j=>['queued','working','saving'].includes(j.status));
    if(job){showJob(job);startPolling(job.id)}
    else if(jobs[0]?.status==='completed') showJob(jobs[0]);
  }catch(err){console.warn('Unable to read video history',err)}
}
init();
