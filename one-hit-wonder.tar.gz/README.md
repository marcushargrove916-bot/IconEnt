# ONE HIT WONDER ✦

**Sora-style, one-tap AI video generator.** A polished, mobile-friendly web app that converts text prompts into short videos with audio, then saves each MP4 on the app server.

## What it does

- **One-button generation** — type a scene, select an optional format, tap *Generate my video*.
- **Real text-to-video** through [Google Gemini Omni Flash 1.1 on fal.ai](https://fal.ai/models/google/gemini-omni-flash/v1.1/text-to-video).
- **Portrait video** for TikTok / Instagram Reels or landscape for YouTube.
- **5, 8, or 10 second** clips; 360p / 720p / 1080p / 4K.
- **Audio** is part of the model's video generation. Describe dialogue/music/SFX in your prompt.
- Live generation progress, playback, **MP4 download**, and a creations library.
- Mobile-first layout and a home-screen icon (installable as a web app when hosted on HTTPS).

## Get real AI generation working

You need **your own fal.ai API key and sufficient credits**. It is a paid video-generation service; ChatGPT does not provide or pay for the API key. Nothing is generated until you connect it.

1. Create a key at <https://fal.ai/dashboard/keys> and enable billing/credits if necessary.
2. On a computer or hosting server with **Python 3.10+**, unzip this folder.
3. In Terminal, open the `one_hit_wonder` folder and run:

   **Mac / Linux:**
   ```bash
   export FAL_KEY='paste-your-fal-key-here'
   python3 server.py
   ```

   **Windows PowerShell:**
   ```powershell
   $env:FAL_KEY='paste-your-fal-key-here'
   py server.py
   ```

4. Open <http://127.0.0.1:8080> in your browser. Type your video idea and tap **Generate my video**.

No pip packages, build tools, or npm install are required. Your API key is used **only by the Python server**, never embedded in browser code.

### Run on your iPhone

You need to deploy the app to a web host that runs Python (for example Render, Railway, or a VPS) and set the `FAL_KEY` environment variable there. Give the server a password by setting `APP_PASSWORD` as well. Once your host provides an HTTPS URL, open the site in iPhone Safari → Share → **Add to Home Screen**. That provides an app-like icon and fullscreen experience. You cannot open `localhost` on your iPhone to reach a server running on somebody else's computer. For development on the same Wi-Fi, use `HOST=0.0.0.0` and open the computer's LAN IP address (protect access and firewall as appropriate).

### Deploy using a generic Python web host

Environment variables:

| Name | Value |
|---|---|
| `FAL_KEY` | Your secret fal.ai API key **(required for rendering)** |
| `APP_PASSWORD` | Strong private password, recommended before exposing online |
| `HOST` | `0.0.0.0` |
| `PORT` | Platform-assigned port, defaults to `8080` |
| `STORAGE_ROOT` | Persistent storage directory on your host (optional) |

Start command: `python3 server.py`. A `render.yaml` Blueprint example is included for Render; it defaults to a free proof-of-concept service, without persistent storage. If deploying via a Git repository on Render, select the Blueprint and enter `FAL_KEY` plus `APP_PASSWORD` when prompted. Free Render services may sleep, restart, and lose the locally saved video history and MP4 files. To retain videos, upgrade to a supported paid plan with a persistent disk, or build external storage into the application.

**Important:** Saved videos and video history are written under `videos/` and `data/` (or under `STORAGE_ROOT` if set). For reliable retention, use a persistent disk/volume on a supported paid host; ephemeral hosting can erase these files when an instance restarts or redeploys. This MVP is intended for private single-user use; do not publicly expose it to unrestricted users without account authentication, abuse controls and billing limits.

## Estimated API costs (provider pricing at creation time)

Gemini Omni Flash 1.1, as listed on fal.ai, is billed per output second:

| Quality | Cost/second | 8-second example |
|---|---:|---:|
| 360p | $0.03 | $0.24 |
| 720p | $0.10 | $0.80 |
| 1080p | $0.15 | $1.20 |
| 4K | $0.30 | $2.40 |

These are **estimates**. Check provider pricing, limits, policy and availability before use. The server prevents more than 2 concurrent render jobs per running instance but is **not** a billing cap.

## Security and limits

- Never put the fal key in the webpage, JavaScript, a public repository, or a message.
- Set `APP_PASSWORD` before putting the app online. It uses browser Basic Authentication over HTTPS.
- Prompt size is capped at 2,500 characters; output video downloads are capped at 150MB each.
- For a production consumer app, add proper login, user-specific storage, a database, rate limits, and spending safeguards.
- Model results depend on provider content filters, network availability and your key/balance.

## What this package does *not* do

This project is a **working application and backend implementation**, not a publicly deployed website or a submitted iOS App Store binary. The included UI works immediately on your local computer; **AI generation requires a valid API key and connection to fal.ai**. No model computation can run in this offline package alone. Actual external generation was not tested with a paid key during development.

## Files

- `server.py` — HTTP server, provider queue polling, MP4 saving and downloads.
- `public/index.html` — app screen.
- `public/styles.css` — responsive design.
- `public/app.js` — API calls and video library.
- `public/manifest.webmanifest` / `public/icons/` — home-screen installation.
- `data/` and `videos/` — persistence (created at runtime).
- `render.yaml` — optional deployment template.

## Idea examples

- “Realistic music video on a Sacramento rooftop at sunset, low tracking camera, moving street lights, bass-heavy instrumental, no visible text.”
- “Luxury hoodie commercial with a moody black studio, slow-motion camera rotation around the model, premium fabric details, modern upbeat music.”
- “A romantic movie scene in the rain at night, close-up expressions and gentle piano.”
